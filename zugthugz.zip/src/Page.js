import React from 'react';
import './Page.css'
import Item from './Item.js'
import Table from 'react-bootstrap/Table'

class Page extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            details: []
        }
    }

    componentDidMount() {
        fetch('https://3w55anstu6.execute-api.us-east-1.amazonaws.com/zug_thugz_get_loot')
            .then(res => res.json())
            .then(
                (result) => {
                    console.log(result)
                    this.setState({details: result["Items"]})
                },
                (error) => {
                    this.setState({
                        error
                    });
                }
            )
    }

    render() {
        return (
            this.state.details.length == 0 ?
                <h2>Loading</h2>
                :
                <div>
                    <h2>{this.state.title}</h2>
                    <Table striped bordered hover variant="dark">
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Raid</th>
                                <th>Boss</th>
                                <th>Slot</th>
                            </tr>
                        </thead>
                        {this.renderItems()}
                    </Table>
                    
                </div>

        )
    }

    renderItems() {
        var items = []
        this.state.details.forEach(element => {
            items.push(<Item key={element.Name} item={element}></Item>);
        });
        
        return items;
    }

}

export default Page;
